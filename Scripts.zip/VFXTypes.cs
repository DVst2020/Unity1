public enum VFXType
{
	Hit,
	FireEffect,
	StepPuff,
	Healing,
	Negative,
	Stronger
}